#import <AppKit/AppKit.h>

@interface ipanelobj : NSView
{
}

- showit;

@end
