#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include "TKlog.h"
int debugFlag = 0;
int writeResiduals=0;
int tcheck = 0;
clock_t timer_clk = 0;
